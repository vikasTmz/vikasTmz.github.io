# Resume

Source files and outputs of my resume template. If you find any part of the repository helpful, please star this github repo.

TODO: 1) Add detailed readme.
2) Learn to write a bit of latex to add links etc to projects.
